# Launcher-V1
I've seen a few projects been using this launcher if your using this please credit me (zinx)
<br><br>
This Launcher Is Made For Eon!

# How To Use
Ive Already Removed The Api That Connected To api.eonfn.com
<br>
Go to [WpfApp6/Pages/Home.xaml.cs](https://github.com/eonfn/Launcher-V1/blob/main/WpfApp6/Pages/Home.xaml.cs)
<br>
Find Where It Says `OMG.DownloadFile("https://cdn.discordapp.com/attachments/1125117879763865642/1125490815372890183/EonCurl.dll", Path.Combine(Path69, "Engine\\Binaries\\ThirdParty\\NVIDIA\\NVaftermath\\Win64", "GFSDK_Aftermath_Lib.x64.dll"));`
<br>This Is On Line 49
<br>
Go To Your Discord Server And Upload Your Curl (Redirect To Fortnite Servers. You Could Use [Aurora Runtimes](https://github.com/Beat-YT/Aurora.Runtime)) <br> After That Copy The Link (make sure it ends with .dll else the link is wrong) <br> Now Back on the source where it says `https://cdn.discordapp.com/attachments/1125117879763865642/1125490815372890183/EonCurl.dll` Chance that to the link you copied!! Wow You Made IT!!!
